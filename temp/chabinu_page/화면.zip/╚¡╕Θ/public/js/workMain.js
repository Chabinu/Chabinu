
/* 콜랩스 메뉴 제어 */
document.getElementById("biz-menu").addEventListener("click", function(){
  document.querySelector(".biz-wrapper").classList.toggle("collapse-true");  
  document.querySelector(".biz-wrapper").classList.toggle("display-none");  
  document.querySelector("#biz-menu").classList.toggle("collpase-true");  
});



